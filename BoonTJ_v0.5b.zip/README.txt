*************************************************************************

BoonDock's TJ mod
Version 0.5b (09.12.2007)

Homepage: http://www.eft-clan.com
E-Mail:   boondock@eft-clan.com
IRC:      #eft-clan @ Q-Net

Save/load based on Kyoto's TJmod 0.4
Thanks to Bennz for his helping hand
Thanks to M!cha for his ideas


*************************************************************************
Description
*************************************************************************

This mod is intended for trickjumping servers. It consists of four
parts: A save/load module, a kill restriction module, and a module for
changing the amount of ammunition and disabling weapons and tools, and
finally a tool to disable votings for a list of maps and campaigns.

-------------------------------------------------------------------------
Save/load
-------------------------------------------------------------------------

This module enables players to save their position and restore it
within the same map/round. It is based on Kotoko's TJmod but enables
saving only when the player is not moving or is dead. This prevents
abusing exploits (like saving when jumping, falling down, sliding on 
ice, etc.). 

Additionally, players can move themselves to another player's position or
move another player to their position. To prevent an abuse of these
features, an admin mod is necessary and these commands have to be
assigned to admin levels. 

-------------------------------------------------------------------------
Kill restriction
-------------------------------------------------------------------------

This mod counts the number of kills a player made (including teamkills) 
and kicks them if a maximum number of kills is reached.

-------------------------------------------------------------------------
Change ammunition / disable weapons
-------------------------------------------------------------------------

With this part of the mod, the initial amount of ammunition can be set. 
Setting the initial amount to 0 disables a weapon. Also most of the 
weapons and tool which do not need ammo can be disabled.

-------------------------------------------------------------------------
Map restriction
-------------------------------------------------------------------------

This part disables voting for a list of maps and campaigns.

-------------------------------------------------------------------------
Permanent adrenaline
-------------------------------------------------------------------------

If enabled, every player can give himself permanent adre by using the
/permadre command. With the same command, the player can switch
adrenaline off.

*************************************************************************
User/Admin Commands
*************************************************************************

/save          saves the player's current position
/load          restores the player's saved position
/permadre      toggles permanent adrenaline
!goto <player> moves the player to another player's position (needs 
               etadmin_mod)
!call <player> moves another player to the player's position (needs 
               etadmin_mod)
!goback        moves the player back to the previous position before he
               was called (needs etadmin_mod)

These commands can be used on players of the same team only.


*************************************************************************
Installation
*************************************************************************

-------------------------------------------------------------------------
ETPro
-------------------------------------------------------------------------

 1. Copy the files BoonTJ.lua and BoonTJ.cfg into the etpro directory of 
    the server.

 2. Add the following line to your server config:

    set lua_modules "BoonTJ.lua"

    If you allready have set the lua_modules cvar, you can add mods by 
    seperating them with a blank, i.e. 

    set lua_modules "combinedfixes.lua BoonTJ.lua"


-------------------------------------------------------------------------
Admin mods (optional)
-------------------------------------------------------------------------

If one of these admin mods is running on the server, the commands !goto, 
!call, and !goback can be used. Otherwise, only /save and /load are 
available. 

-----------
Etadmin_mod
-----------

Add the following lines to the [alias] section of your etadmin.cfg file:

 # BoonTJ
 goto   = goto "<CLIENT_ID>" "<PART2ID>"
 call   = call "<CLIENT_ID>" "<PART2ID>"
 goback = goback "<CLIENT_ID>"

Add the following lines to the [permissions] section of your etadmin.cfg
file:

 # BoonTJ
 1 = goto
 1 = call
 0 = goback

goback should be assigned to level 0, feel free to assign other admin 
levels to goto and call.

----
KMOD
----

Add the following lines to the end of your commands.cfg file: 

# BoonTJ
1 - goto   = goto   <CLIENT_ID> <PNAME2ID>
1 - call   = call   <CLIENT_ID> <PNAME2ID>
0 - goback = goback <CLIENT_ID>

goback should be assigned to level 0, feel free to assign other admin 
levels to goto and call.


*************************************************************************
Configuration
*************************************************************************

For configuring the BoonTJ mod, open the BoonTJ.cfg file with an editor.

-------------------------------------------------------------------------
General configuration options
-------------------------------------------------------------------------

The btj_check_ms parameter is to configure the interval to check for 
ammunition and if a player is moving. 50 ms is the lowest possible value 
and gives a good check accuracy but higher values reduce server load.

 set btj_check_ms 50

-------------------------------------------------------------------------
Enable/disable features
-------------------------------------------------------------------------

Features can be enabled or disabled by setting the responsive cvar value
to 1 or 0.

Enable/disable the save/load feature

 set btj_enable_save_load        1/0

Enable/disable the goto/call/goback feature. This feature works only if an
admin mod is installed.

 set btj_enable_goto_call_goback 1/0

Enable/disable the kill restriction

 set btj_enable_killrestriction  1/0

Enable/disable the ammo module

 set btj_enable_ammo_mod         1/0

Enable/disable the map/campaign voting restriction

 set btj_enable_map_restriction  1/0

Enable/disable the permanent adrenaline feature

 set btj_enable_permadre  1/0

-------------------------------------------------------------------------
Save/load
-------------------------------------------------------------------------

This section configures the saving options. Saving can be disabled when a
player is moving or dead by setting the responsive cvar to 1.

set btj_disable_saving_while_moving 1/0
set btj_disable_saving_while_dead   1/0

-------------------------------------------------------------------------
Kill restriction
-------------------------------------------------------------------------

For the kill restriction module, 2 parameters can be set: The number of 
kills a player can make until he gets kicked as well as the time he gets 
temporarily banned.

set btj_kill_limit 3
set btj_bantime    120

-------------------------------------------------------------------------
Change amount of ammunition
-------------------------------------------------------------------------

In this section the amount of ammunition a player spawns with can be set.
ammoclip cvars are for the amount of ammunition in the weapon, ammo cvars
set the number of extra ammunition.

       -1 for the default number of ammunition
        0 for disabling the weapon (make sure you disable both ammoclip and ammo)
  1 - 999 for the number of ammunition when spawning
    > 999 for unlimited ammunition

 // common weapons
 set btj_ammoclip_luger               -1
 set btj_ammoclip_akimbo_luger        -1
 set btj_ammo_luger                   -1
 set btj_ammoclip_colt                -1
 set btj_ammoclip_akimbo_colt         -1
 set btj_ammo_colt                    -1
 set btj_ammo_mp40                    -1
 set btj_ammoclip_mp40                -1
 set btj_ammo_thompson                -1
 set btj_ammoclip_thompson            -1
 set btj_ammoclip_axis_grenades       -1
 set btj_ammoclip_allies_grenades     -1

 // soldier weapons
 set btj_ammoclip_panzerfaust         -1
 set btj_ammoclip_flamethrower        -1
 set btj_ammo_mortar                  -1
 set btj_ammoclip_mg42                -1
 set btj_ammo_mg42                    -1

 // medic weapons
 set btj_ammoclip_syringe_adre        -1

 // engineer weapons
 set btj_ammoclip_axis_engi_rifle     -1
 set btj_ammo_axis_engi_rifle         -1
 set btj_ammoclip_axis_rifle_nade     -1
 set btj_ammo_axis_rifle_nade         -1
 set btj_ammoclip_allies_engi_rifle   -1
 set btj_ammo_allies_engi_rifle       -1
 set btj_ammoclip_allies_rifle_nade   -1
 set btj_ammo_allies_rifle_nade       -1

 // fieldops weapons

 // covertops weapons
 set btj_ammoclip_sten                -1
 set btj_ammo_sten                    -1
 set btj_ammoclip_fg42                -1
 set btj_ammo_fg42                    -1
 set btj_ammoclip_axis_covert_rifle   -1
 set btj_ammo_axis_covert_rifle       -1
 set btj_ammoclip_allies_covert_rifle -1
 set btj_ammo_allies_covert_rifle     -1

-------------------------------------------------------------------------
 Disable weapons/tools without ammo
-------------------------------------------------------------------------

In this section, most weapons and tools which need no ammo can be disabled.
Unfortunately knife and arty cannot be disabled and disabling the 
engineer's tool still shows the pliers (but cannot they be used though).

 0 enables the weapon/tool
 1 disables the weapon/tool

 // medic
 set btj_disable_medpack    0/1

 // engineer
 set btj_disable_pliers     0/1
 set btj_disable_dynamite   0/1
 set btj_disable_landmine   0/1

 // fieldops
 set btj_disable_ammopack   0/1
 set btj_disable_airsrtrike 0/1

 // covertops
 set btj_disable_satchel    0/1
 set btj_disable_smoke      0/1

-------------------------------------------------------------------------
 Disable map/campaign votings
-------------------------------------------------------------------------

Maps and campaigns which should not be allowed to be voted for can be 
disabled with the btj_disallowed_maps and btj_disallowed_campaignssetting. 
Up to 50 maps/10 campaigns can be added, seperated by a blank.

 set btj_disallowed_maps      "battery fueldump goldrush oasis radar railgun"
 set btj_disallowed_campaigns "cmpgn_centraleurope cmpgn_northafrica"

-------------------------------------------------------------------------
 Editing messages
-------------------------------------------------------------------------

For changing the in-game messages, open the BoonTJ.lua file and you will 
find the messages section in the beginning of that file.

Changes to this should be done by advanced users only so I don't give a
more detailed explanation here.


*************************************************************************
Version history
*************************************************************************

-------------------------------------------------------------------------
 Version 0.1 (15.08.2007)
-------------------------------------------------------------------------

Initial release.

-------------------------------------------------------------------------
 Version 0.2 (16.08.2007)
-------------------------------------------------------------------------

Made movement check interval adjustable to reduce server load.
Added a check to prevent saving when a player is dead.

-------------------------------------------------------------------------
 Version 0.3b (17.08.2007)
-------------------------------------------------------------------------

Moved configuration into a seperate config file.
Features can be turned on/off.
Added a kill restriction module.
Added a ammunition amount modifier.

-------------------------------------------------------------------------
 Version 0.4 (18.08.2007)
-------------------------------------------------------------------------

Most Weapons/tools without ammo can be disabled.
Saving while moving or being dead can be disabled or enabled.

-------------------------------------------------------------------------
 Version 0.5 (22.08.2007)
-------------------------------------------------------------------------

Added a map/campaign voting restriction system.
Fixed a few minor bugs.

-------------------------------------------------------------------------
 Version 0.5a (28.08.2007)
-------------------------------------------------------------------------

Just a small code update for easier editing of messages.

-------------------------------------------------------------------------
 Version 0.5b (09.12.2007)
-------------------------------------------------------------------------

Added permanent adrenaline.

*************************************************************************